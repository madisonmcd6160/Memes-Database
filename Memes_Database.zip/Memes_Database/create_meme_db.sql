/* 
create_meme_db.sql
Madison McDonald
April 17, 2024
Database for the meme store
*/

/*****************************************
* Create the meme_store_db database
*****************************************/
DROP DATABASE IF EXISTS meme_store_db1;
CREATE DATABASE meme_store_db1;
USE meme_store_db1;

-- create the tables for the database
CREATE TABLE customers (
  customerID        INT            NOT NULL   AUTO_INCREMENT,
  emailAddress      VARCHAR(255)   NOT NULL,
  password          VARCHAR(60)    NOT NULL,
  firstName         VARCHAR(60)    NOT NULL,
  lastName          VARCHAR(60)    NOT NULL,
  shipAddressID     INT                       DEFAULT NULL,
  billingAddressID  INT                       DEFAULT NULL,  
  PRIMARY KEY (customerID),
  UNIQUE INDEX emailAddress (emailAddress)
);

CREATE TABLE addresses (
  addressID         INT            NOT NULL   AUTO_INCREMENT,
  customerID        INT            NOT NULL,
  line1             VARCHAR(60)    NOT NULL,
  line2             VARCHAR(60)               DEFAULT NULL,
  city              VARCHAR(40)    NOT NULL,
  state             VARCHAR(2)     NOT NULL,
  zipCode           VARCHAR(10)    NOT NULL,
  phone             VARCHAR(12)    NOT NULL,
  disabled          TINYINT(1)     NOT NULL   DEFAULT 0,
  PRIMARY KEY (addressID),
  INDEX customerID (customerID)
);

CREATE TABLE orders (
  orderID           INT            NOT NULL   AUTO_INCREMENT,
  customerID        INT            NOT NULL,
  orderDate         DATETIME       NOT NULL,
  shipAmount        DECIMAL(10,2)  NOT NULL,
  taxAmount         DECIMAL(10,2)  NOT NULL,
  shipDate          DATETIME                  DEFAULT NULL,
  shipAddressID     INT            NOT NULL,
  cardType          INT            NOT NULL,
  cardNumber        CHAR(16)       NOT NULL,
  cardExpires       CHAR(7)        NOT NULL,
  billingAddressID  INT            NOT NULL,
  PRIMARY KEY (orderID), 
  INDEX customerID (customerID)
);

CREATE TABLE orderItems (
  itemID            INT            NOT NULL   AUTO_INCREMENT,
  orderID           INT            NOT NULL,
  productID         INT            NOT NULL,
  itemPrice         DECIMAL(10,2)  NOT NULL,
  discountAmount    DECIMAL(10,2)  NOT NULL,
  quantity          INT NOT NULL,
  PRIMARY KEY (itemID), 
  INDEX orderID (orderID), 
  INDEX productID (productID)
);

CREATE TABLE products (
  productID         INT            NOT NULL   AUTO_INCREMENT,
  categoryID        INT            NOT NULL,
  productCode       VARCHAR(10)    NOT NULL,
  productName       VARCHAR(255)   NOT NULL,
  description       TEXT           NOT NULL,
  image             TEXT           NOT NULL,
  listPrice         DECIMAL(10,2)  NOT NULL,
  discountPercent   DECIMAL(10,2)  NOT NULL   DEFAULT 0.00,
  dateAdded         DATETIME       NOT NULL,
  PRIMARY KEY (productID), 
  INDEX categoryID (categoryID), 
  UNIQUE INDEX productCode (productCode)
);

CREATE TABLE categories (
  categoryID        INT            NOT NULL   AUTO_INCREMENT,
  categoryName      VARCHAR(255)   NOT NULL,
  PRIMARY KEY (categoryID)
);

CREATE TABLE administrators (
  adminID           INT            NOT NULL   AUTO_INCREMENT,
  emailAddress      VARCHAR(255)   NOT NULL,
  password          VARCHAR(255)   NOT NULL,
  firstName         VARCHAR(255)   NOT NULL,
  lastName          VARCHAR(255)   NOT NULL,
  PRIMARY KEY (adminID)
);

-- Insert data into the tables
INSERT INTO categories (categoryID, categoryName) VALUES
(1, 'Humorous'),
(2, 'Political'),
(3, 'Animals');

INSERT INTO products (productID, categoryID, productCode, productName, description, image, listPrice, discountPercent, dateAdded) VALUES
(1, 1, 'Kids', 'Funny kids', 'Two kids riding in laundry baskets with watermelon helmets',
'https://hips.hearstapps.com/hmg-prod/images/hilariously-funny-jokes-watermelon-644ad2430788a.jpg?crop=0.668xw:1.00xh;0.264xw,0&resize=1200:*',
'11.50', '3.00', '2024-4-3 12:19'),

(2, 2, 'Political', 'Trumpanzie', 'Insulting meme for the worst president of all times',
'https://i.ytimg.com/vi/hyN3esUGdm8/maxresdefault.jpg', '12.50','1.25', '2024-4-1 12:52'),

(3, 3, 'Kitten', 'Baby Cat', 'Cute picture of a baby cat', 'https://media.istockphoto.com/id/1345942562/photo/kitten-british-cat-looking-at-camera.webp?b=1&s=170667a&w=0&k=20&c=wQkssm8ZKJcJZQd0oEO6BL1CVTrK0jaD_3IDuzF2Wqw=',
'10.50', '1.30', '2024-4-3 12:52'),

(4, 3, 'Funny', 'Dog Bread', 'Funny picture of a dog in bread', 'https://www.rd.com/wp-content/uploads/2020/11/GettyImages-889552354-e1606774439626.jpg',
'11.50', '1.00', '2024-4-3 12:06'),

(5, 3, 'Chat', 'Parrots', 'Two parrots gossiping to eachother', 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/ba/Thick-billed_parrots_in_a_U.S._zoo.jpg/640px-Thick-billed_parrots_in_a_U.S._zoo.jpg',
'13.50', '3.00', '2024-4-3 12:08'),

(6, 3, 'Party', 'Sunglasses Raccoon', 'Raccoon wearing sunglasses ready to party', 'https://media.istockphoto.com/id/1154370446/photo/funny-raccoon-in-green-sunglasses-showing-a-rock-gesture-isolated-on-white-background.jpg?s=612x612&w=0&k=20&c=kkZiaB9Q-GbY5gjf6WWURzEpLzNrpjZp_tn09GB21bI=',
'10.50', '1.00', '2024-4-3 12:10'),

(7, 3, 'Dog', 'Relaxing Dog', 'Dog relaxing eating popcorn watching TV', 'https://media.istockphoto.com/id/680810342/photo/dog-watching-tv-on-the-couch.jpg?s=612x612&w=0&k=20&c=CQXmfuqlwL49GhcLDXIQSEZwq3iGpIkPJneWJUiI_0U=',
'9.50', '1.00', '2024-4-3 12:12'),

(8, 1, 'Laugh', 'Man Laughing', 'Man pointing and laughing at you', 'https://image-service.usw2.wp-prod-us.cultureamp-cdn.com/OqjzT0ErD2k23PVq3gNsGKXkiJY=/1440x0/cultureampcom/production/1e4/ddf/e68/1e4ddfe687e3363fe3f2e78b/blog-90-funny-jokes-to-share-with-coworkers.png',
'11.00', '2.00', '2024-4-3 12:13'),

(9, 3, 'Cute', 'Cat Face', 'Cat making a funny face', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzghvBcGRMT9iBMLBySx8CoHomlZXDPqW_mZRs0GDQkA&s',
'13.00', '1.00', '2024-4-3 12:15'),

(10, 3, 'Surprised', 'Surprised Animal', 'Animal making a surprised face', 'https://i.natgeofe.com/k/baf4215e-517c-49b4-84f4-8e63cd5e5913/ww-funny-animal-faces-lemur_square.jpg',
'12.00', '1.00', '2024-4-3 12:17'),

(11, 1, 'shari', 'Shari Bemis', 'Dr. Shari Bemis generated by Prodia AI.', 
'https://cdn.discordapp.com/attachments/1064921910917476365/1224801598006493335/cover-886069597141872.png?ex=661ed060&is=660c5b60&hm=2fd8927c7f74f3342d836615df8687916fb8a50a36b2a0eb95b6e695075d25c2&',
'0.25', '0', '2024-04-01 01:07:00'),

(12, 1, 'wei', 'Wei Lu', 'Dr. Wei Lu generated by Prodia AI.', 
'https://cdn.discordapp.com/attachments/1064921910917476365/1224801597507375195/cover-45960331892673767.png?ex=661ed060&is=660c5b60&hm=ba419eeba7a7de83606e68c251bf8dc1479f3955190e9652f0764e6c03717445&',
'0.25', '0', '2024-04-01 01:07:00'),

(13, 1, 'foster', 'Elvis Foster', 'Dr. Elvis Foster generated by Prodia AI.', 
'https://cdn.discordapp.com/attachments/1064921910917476365/1224801596278440006/cover-18452814341721324.png?ex=661ed060&is=660c5b60&hm=ff2db68b7c4f6f6e7bd612028e9979eead75300a22469dd8ff06a8b8132cae75&', 
'0.25', '0', '2024-04-01 01:07:00'),

(14, 1, 'onyon', 'Matt Onyon', 'Professor Matt Onyon generated by Prodia AI.', 
'https://cdn.discordapp.com/attachments/1064921910917476365/1224801596723171358/cover-1660681516757292.png?ex=661ed060&is=660c5b60&hm=7b67b85c0d596bff91a857997074475f1fbc9c9cf9d58281b6087f796c1b7557&', 
'0.25', '0', '2024-04-01 01:07:00'),

(15, 1, 'gauvreau', 'Ken Gauvreau', 'Professor Ken Gauvreau generated by Prodia AI.', 
'https://cdn.discordapp.com/attachments/1064921910917476365/1224801598614802512/cover-29779366436623134.png?ex=661ed060&is=660c5b60&hm=c2eab0450b16527d8781d3e8a07e55b371ff5da7212fd0cc052eccb119cf17f9&', 
'0.25', '0', '2024-04-01 01:07:00'),

(16, 3, 'bruce', 'Bruce', 'Bruce, belonging to Dr. Foster, generated by Prodia AI.', 
'https://cdn.discordapp.com/attachments/1064921910917476365/1224801975745515682/cover-22867033523731828.png?ex=661ed0ba&is=660c5bba&hm=5fb5c7e30fcfb3c9f6606e6bfd2d190191d594c0651b69418fb0ba991fddc98f&', 
'0.25', '0', '2024-04-01 01:07:00'),

(17, 3, 'lambert', 'Lambert', 'Lambert, belonging to Dr. Foster, generated by Prodia AI.', 
'https://cdn.discordapp.com/attachments/1064921910917476365/1224801976349491270/cover-4802942884896171.png?ex=661ed0ba&is=660c5bba&hm=9d28a731a2313afad6a2031a64432dd60af1b39cad7d873f13bff7e5caf461a6&', 
'0.25', '0', '2024-04-01 01:07:00'),

(18, 1, 'rice', 'Ricey-Chan', 'Ricey-Chan is our Lord and Savior of Computer Science. 
This depiction of him is generated by Prodia AI.', 'https://cdn.discordapp.com/attachments/1064921910917476365/1224801977448267876/cover-6408242715316013.png?ex=661ed0bb&is=660c5bbb&hm=0b0305d7a25cd5a394cf28c9cd866033839523757d250620b4f6a175c5c22876&', 
'0.25', '0', '2024-04-01 01:07:00'),

(19, 3, 'leona', 'Leona', 'Leona is the assistant of Ricey-Chan. 
This depiction of her is generated by Prodia AI.', 'https://cdn.discordapp.com/attachments/1064921910917476365/1224801977016389843/cover-042198880481473244.png?ex=661ed0bb&is=660c5bbb&hm=4a005625c1a9699a03e0c3d657ad683b3c3a9e1ed9113959f82932b60ab4ba4f&', 
'0.25', '0', '2024-04-01 01:07:00'),

(20, 1, 'richie', 'Richard Phipps', 'What the Richie doing? Generated by Prodia AI.', 
'https://cdn.discordapp.com/attachments/1064921910917476365/1224801977943326892/cover-7618591356684501.png?ex=661ed0bb&is=660c5bbb&hm=370eb0d8f234b43cf92147682c1674e4773450ff35fb52a4a7e84b2c1c256dbc&', 
'0.25', '0', '2024-04-01 01:07:00'),

(21, 2, 'POL-OBAMA', 'Obama Mic Drop', 'Iconic moment of Obama dropping the mic.', 
'https://media.tenor.com/5iXomuvuRQ4AAAAe/drop-the-mic-obama-mic-drop.png', 
'13.00', '10.00', '2024-4-1 14:00:00'),

(22, 2, 'POL-BERNIE', 'Bernie Mittens', 'Bernie Sanders wearing mittens at the inauguration.', 
'https://bemyeyes-assets.s3.amazonaws.com/podcasts/smm/podcast-cover-Barnie-Sanders.jpg', 
'12.50', '1.25', '2024-4-1 14:10:00'),

(23, 2, 'POL-TRUMPWALL', 'Trump Wall', 'Humorous take on the proposed wall.', 
'https://ichef.bbci.co.uk/news/976/cpsprodpb/1011/production/_93831140_meme1.png', 
'15.00', '10', '2024-4-1'),

(24, 3, 'ANM-CATLOAF', 'Cat Loaf', 'A cat sitting like a loaf of bread.', 
'https://scontent-lga3-1.xx.fbcdn.net/v/t39.30808-6/322976458_2545448458920164_5180941917094382185_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=PD9-nipFEggAX-U3cH0&_nc_ht=scontent-lga3-1.xx&oh=00_AfAWvfMFkj1Vc4bDC195OriISuyoqPjz1KlM5jCjymHvpA&oe=6610D0C9',
'10.00', '0', '2024-4-1'),

(25, 1, 'HUM-KERMIT', 'Kermit Sipping Tea', 'Kermit the Frog sipping tea, none of my business meme.', 
'https://cdn.vox-cdn.com/thumbor/FqeDwVRL_fMN6Uj4C2gJRsN2btQ=/0x0:494x411/1400x1400/filters:focal(247x205:248x206)/cdn.vox-cdn.com/uploads/chorus_asset/file/15851232/slack-imgs-1.com.0.0.1466520554.jpeg', 
'11.00', '0', '2024-4-1'),

(26, 1, 'HUM-THISISFINE', 'This is Fine', 'A dog sitting in a room on fire, calmly stating "This is fine."', 
'https://media.npr.org/assets/img/2023/01/14/this-is-fine_wide-0077dc0607062e15b476fb7f3bd99c5f340af356-s1400-c100.jpg', 
'12.50', '0.50', '2024-4-1'),

(27, 3, 'ANM-LONGCAT', 'Long Cat', 'One of the internets most famous cats known for its incredible length.', 
'https://upload.wikimedia.org/wikipedia/en/3/3d/Longcat_is_loooooooooong.jpg', 
'11.50', '0.50', '2024-4-1'),

(28, 1, 'HUM-SUCCESSKID', 'Success Kid', 'The iconic image of a baby with a determined look, clenching a fist in triumph, often used to symbolize small but significant victories.', 
'https://upload.wikimedia.org/wikipedia/en/f/ff/SuccessKid.jpg', 
'12.00', '0', '2024-4-1'),

(29, 1, 'HUM-PICARDFACEPALM', 'Picard Facepalm', 'A meme featuring Captain Jean-Luc Picard from "Star Trek: The Next Generation" performing a facepalm, symbolizing frustration or disbelief.', 
'https://i.stack.imgur.com/pB43k.jpg', 
'13.00', '0', '2024-4-1'),

(30, 1, 'HUM-YOUDONTSAY', 'You Dont Say?', 'A meme derived from a scene featuring Nicolas Cage, used to sarcastically express that something is obvious.', 
'https://media.tenor.com/V1nzNc4rZE8AAAAe/you-dont-say-nic-cage.png', 
'13.50', '5.00', '2024-4-1'),

(31, 3, 'relaxed', 'Relaxed Rabbit', 'A rabbit chilling and relaxing.', 
'https://i.pinimg.com/236x/ca/83/05/ca8305499a80048d9933c486501d455f.jpg', 
'7.49', '1', '2024-04-01 14:00'),

(32, 3, 'grinning', 'Grinning Cat', 'A cat with a wide grin.', 
'https://static.wikia.nocookie.net/belugacinematicuniversefanon/images/6/6a/Beluga.jpg/revision/latest/thumbnail/width/360/height/360?cb=20231226224904', 
'6.99', '2', '2024-04-01 14:00'),

(33, 3, 'sleeping', 'Sleeping Dog', 'A dog all tucked in and sleeping.', 
'https://ih1.redbubble.net/image.489735421.7354/raf,360x360,075,t,fafafa:ca443f4786.jpg', 
'5.90', '3', '2024-04-01 14:00'),

(34, 3, 'derp', 'Derp Turtle', 'A turtle making a silly face', 
'https://i.kym-cdn.com/entries/icons/facebook/000/042/359/cover9.jpg', 
'4.99', '4', '2024-04-01 14:00'),

(35, 3, 'smiling', 'Smiling Sloth', 'A sloth with a big smile', 
'https://i.imgflip.com/16hyx.jpg?a475128', 
'7.99', '5', '2024-04-01 14:00'),

(36, 3, 'dancing', 'Dancing Penguin', 'A penguin dancing joyfully', 
'https://media.tenor.com/ded_wRra_HcAAAAj/penguin-dancing.gif', 
'8.49', '6', '2024-04-01 14:00'),

(37, 3, 'sad', 'Sad Hamster', 'A hamster looking very sad', 
'https://i.kym-cdn.com/entries/icons/original/000/048/516/Screenshot_2024-02-20_at_10.43.43_AM.jpg', 
'4.99', '7', '2024-04-01 14:00'),

(38, 3, 'laughing', 'Laughing Llama', 'A llama laughing hysterically', 
'https://c.tenor.com/I2enaNSg2A8AAAAC/tenor.gif', 
'6.29', '8', '2024-04-01 14:00'),

(39, 3, 'fallen', 'Fallen Elephant', 'An elephant that has fallen', 
'https://i.imgflip.com/1kkdi1.jpg', '9.99', '9', '2024-04-01 14:00'),

(40, 3, 'Shocked', 'Surprised Squirrel', 'A squirrel with a surprised expression', 
'https://i.imgflip.com/2n7i4f.jpg', '3.99', '10', '2024-04-01 14:00'),

(41, 3, 'meme1', 'CatMeme1', 'A cat looking absolutely flabbergasted.', 
'https://media.tenor.com/rAzwgJolpQkAAAAM/cat.gif', '10.00', '30.00', '2024-4-1 11:58:00'),

(42, 3, 'meme2', 'CatMeme2', 'A very sad looking cat.', 
'https://i.kym-cdn.com/entries/icons/mobile/000/026/489/crying.jpg', '20.00', '10.00', '2024-4-1 12:01:00'),

(43, 3, 'meme3', 'CatMeme3', 'A very angry kitty.', 
'https://i.pinimg.com/736x/62/62/7a/62627a64819e384ff32a39a720ca15e1.jpg', '15.00', '20.00', '2024-4-1 12:02:00'),

(44, 1, 'meme4', 'HumorMeme1', 'Bibble from a Barbie movie causing chaos.', 
'https://i.pinimg.com/736x/eb/08/b9/eb08b9f6ae46db06347c0b213eec5861.jpg', '5.00', '1.00', '2024-4-1 12:03:00'),

(45, 3, 'meme5', 'CatMeme4', 'A large cat in a very small box.', 
'https://i.imgflip.com/26qbbj.jpg', '50.00', '10.00', '2024-4-1 12:04:00'),

(46, 3, 'meme6', 'CatMeme5', 'An EXTREMELY upset cat.', 
'https://lh3.googleusercontent.com/proxy/R4FiBHYFwXAL8OeVFdAJu1I8fn4l-8PVY9jpCpzdGYDvsR-3Ft0m18m6SBIfMGTPNvNR7nE8W-einrK7o6Ytnajr0Ofh2mK2bAkjgwr3LR7mfZ6YxHJMbH5ffbv0OQ04WJs', 
'7.00', '30.00', '2024-4-1 12:04:00'),

(47, 1, 'meme7', 'HumorMeme2', 'A very funny looking cat(?) sculpture.', 
'https://ih1.redbubble.net/image.949021450.7413/flat,750x,075,f-pad,750x1000,f8f8f8.jpg', '100.00', '3.00', '2024-4-1 12:06:00'),

(48, 3, 'meme8', 'CatMeme6', 'A cat on the verge of projectile vomiting.', 
'https://us-tuna-sounds-images.voicemod.net/a071acf4-7eca-48b0-9482-b7ab8812f6f1-1702070043108.jpg', '1000.00', '35.00', '2024-4-1 12:07:00'),

(49, 1, 'meme9', 'HumorMeme3', 'A very shocked Pikachu.', 
'https://i.kym-cdn.com/entries/icons/original/000/027/475/Screen_Shot_2018-10-25_at_11.02.15_AM.png', '9.00', '9.00', '2024-4-1 12:08:00'),

(50, 3, 'meme10', 'CatMeme7', 'A kitty dozing off.', 
'https://external-preview.redd.it/M2S-GqIaRD8Qt3q-AdApIQU7oB2hTctCL77ESZQt88o.jpg?auto=webp&s=4d10352be75f57b695e6e3ec269860735b07440d', 
'1000.00', '30.00', '2024-4-1 12:08:00'),

(51, 3, 'memes1', 'AverageCSStudent', 'cs student', 'https://media.tenor.com/rAzwgJolpQkAAAAM/CS.gif', 
'10.00', '30.00', '2024-4-1 11:10:00'),

(52, 2, 'CSSStudent', 'AverageCSStudent', 'cs student2', 'https://i.kym-cdn.com/entries/icons/mobile/000/026/489/cs2.jpg', 
'20.00', '10.00', '2024-4-1 12:20:00'),

(53, 3, 'csmeme4', 'CSStudentCheckingCanvas', 'Angry CS Student', 'https://i.pinimg.com/736x/62/62/7a/62927a21819e314ff32a39a720ca15e1.jpg', 
'15.00', '20.00', '2024-4-1 12:02:00'),

(54, 3, 'CsMeme5', 'CSStudentCodingonFiveDifferentMonitors', 'CS student using different computers', 'https://i.imgflip.com/26qbbj.jpg', '50.00', '10.00', '2024-4-1 12:32:00'),

(55, 3, 'DCFood', 'CSStudentintheDC', 'CS student at the DC', 'https://lh3.googleusercontent.com/proxy/R4FiBHYFwXAL8OeVFdAJu1I8fn4l-8PVY9jpCpzdGYDvsR-3Ft0m11m7SBIfMGTPNvNR7nE8W-einrK7o6Ytnajr0Ofh2mK2bAkjgwr3LR7mfZ6YxHJMbH5ffbv0OQ04WJs', 
'7.00', '30.00', '2024-4-1 12:04:00'),

(56, 1, 'memes7', 'CSStudentLeavingtheDiningCommons', 'CS student leaving the DC', 'https://ih1.imgr.net/image.949363450.7413/flat,750x,075,f-pad,750x1000,f8f7f8.jpg', 
'100.00', '3.00', '2024-4-1 12:41:00'),

(57, 2, 'CSLloyds2', 'CSatLloyds', 'CS student at Lloyds', 'https://i.kys-nac.com/entries/icons/000/027/475/2024-4-25_at_11.02.15_AM.png', 
'9.00', '9.00', '2024-4-1 12:50:00'),

(58, 2, 'CSLloyds3', 'CSStudentHappy2', 'CSStudentwithChickenSandwich.', 'https://external-preview.redd.it/M2S-GkljRD8Qt3q-AdBpIQU7oB3hTctCL11ESZQt88o.jpg?auto=webp&s=4d10352be75f57b695e6e3ec269860735b07440d', 
'1000.00', '30.00', '2024-4-1 12:55:00'),

(59, 1, 'F1-TOTO-VER', 'Toto vs Verstappen', 'A humorous take on the rivalry between Toto Wolff and Max Verstappen', 
'https://giphy.com/gifs/f1-toto-verstappen-wolff-UpExHeypPdNXcNwCSD', '14.00', '5.00', '2024-04-01'),

(60, 1, 'F1-ANNOYED-TOTO', 'Annoyed Toto Wolff', 'Toto Wolff showing his frustration', 
'https://giphy.com/gifs/f1-annoyed-frustrated-cAvJW4wdPHqjgsGaac', '14.00', '5.00', '2024-04-01'),

(61, 1, 'F1-TOTO-LAUGH', 'Toto Wolff Laughing', 'A lighter moment with Toto Wolff laughing', 
'https://giphy.com/gifs/mercedesamgf1-mercedes-amg-f1-toto-wolff-8cSRYjFVJMXxlpaNw4', '14.00', '5.00', '2024-04-01'),

(62, 1, 'F1-GEORGE-RUSSELL', 'George Russell - F1 Titles', 'George Russell featured in the 2023 F1 opening titles', 
'https://leclerqued.tumblr.com/post/710690522084327424/george-russell-2023-f1-opening-titles', '14.00', '5.00', '2024-04-01'),

(63, 1, 'MEME-HAM-LAUGH', 'Hamilton Laughing', 'Lewis Hamilton laughing in a candid moment. Perfect for light-hearted situations', 
'https://giphy.com/gifs/f1-formula-1-hamilton-lewis-uzOSCSVYB4Vz2oO77M', '14.00', '5.00', '2024-04-01'),

(64, 1, 'RBR-WINNING', 'Red Bull Racing Victory', 'Celebrating a win with the Red Bull Racing team', 
'https://giphy.com/gifs/redbullracing-f1-red-bull-racing-tzMcBHbVaE9NnYgdbr', '14.00', '5.00', '2024-04-01'),

(65, 1, 'MER-TEAM-CELEB', 'Mercedes Team Celebration', 'The Mercedes team celebrates a victory', 
'https://giphy.com/gifs/mercedesamgf1-f1-formula-1-one-fUkxZbbIASj0RUhjwC', '14.00', '5.00', '2024-04-01'),

(66, 1, 'F1-RACING-THRILL', 'Racing Thrill', 'Capturing the thrill of Formula 1 racing', 
'https://giphy.com/gifs/f1-4T08t8psvc1YJXWkmu', '14.00', '0.00', '2024-04-01'),

(67, 1, 'MEME-RUSSELL-SMILE', 'Russells Winning Smile', 'George Russell showing his winning smile. A moment of joy', 
'https://imgflip.com/i/8l8lxl', '14.00', '5.00', '2024-04-01'),

(68, 1, 'F1-MERC-DUO', 'Mercedes Duo', 'Lewis Hamilton and George Russell in a Mercedes moment', 
'https://tenor.com/view/mercedes-george-russell-lewis-hamilton-formula-1-f1-gif-18110942413476787222', 
'14.00', '5.00', '2024-04-01'),

(69, 1, 'Boyfriend', 'Distracted Boyfriend Meme Poster', 'Capture the essence of internet culture with this iconic poster featuring the Distracted Boyfriend meme. Perfect for your dorm room or office.', 'https://knowyourmeme.com/memes/distracted-boyfriend', 9.99, 0, NULL),

(70, 3, 'Grumpy_Cat', 'Grumpy Cat Plush Toy', 'Cuddle up with everyone''s favorite sourpuss! This plush toy captures the eternal displeasure of Grumpy Cat in adorable form.', 'https://knowyourmeme.com/memes/grumpy-cat', 14.99, 0, NULL),

(71, 1, 'RickRoll', 'Rickroll Alarm Clock', 'Never gonna give you up, never gonna let you snooze! Start your day with a smile (or a groan) with this Rickroll Alarm Clock.', 'https://knowyourmeme.com/memes/rickroll', 19.99, 0, NULL),

(72, 1, 'Emoji', 'Facepalm Emoji Pillow', 'Express your exasperation in real life with this plush Facepalm Emoji Pillow. Perfect for those facepalm-worthy moments.', 'https://emojipedia.org/facepalm/', 12.99, 0, NULL),

(73, 3, 'NyanCat', 'Nyan Cat Backpack', 'Take the rainbow-tailed sensation everywhere you go with this Nyan Cat Backpack. Perfect for school, work, or intergalactic adventures.', 'https://knowyourmeme.com/memes/nyan-cat', 29.99, 0, NULL),

(74, 3, 'KeyboardCat', 'Keyboard Cat Musical Keyboard', 'Play your favorite tunes with the spirit of Keyboard Cat! This musical keyboard features pre-recorded cat-inspired melodies for endless amusement.', 'https://knowyourmeme.com/memes/play-him-off-keyboard-cat', 49.99, 0, NULL),

(75, 1, 'Girlfriend', 'Overly Attached Girlfriend Stalker Set', 'Get the complete stalker experience with this Overly Attached Girlfriend Stalker Set. Includes binoculars, disguises, and a restraining order template.', 'https://knowyourmeme.com/memes/overly-attached-girlfriend', 39.99, 0, NULL),

(76, 1, 'SpongeBob', 'SpongeBob Mocking Meme Mug', 'Start your day with a laugh and a cup of coffee in this SpongeBob Mocking Meme Mug. Perfect for mocking your morning routine.', 'https://knowyourmeme.com/memes/mocking-spongebob', 9.99, 0, NULL),

(77, 3, 'Pikachu', 'Surprised Pikachu Plush', 'Recreate the meme magic with this adorable Surprised Pikachu Plush. Guaranteed to evoke smiles and nostalgia.', 'https://knowyourmeme.com/memes/surprised-pikachu', 17.99, 0, NULL),

(78, 1, 'Tshirt', '"That Escalated Quickly" T-shirt', 'Let everyone know when things take an unexpected turn with this "That Escalated Quickly" T-shirt. Available in sizes S-XXL.', 'https://knowyourmeme.com/memes/that-escalated-quickly', 14.99, 0, NULL),

(79, 1, 'f1 meme 1', 'Max Verstappen kicking tire', 'Max Verstappen kicks tire after it blows out during race', 'https://indeksonline.net/wp-content/uploads/2021/06/max-verstappen-of-netherlands-and-red-bull-racing-kicks-his-news-photo-1623100013-1536x1024.jpg', '10.00', '0.00', '2024-4-7 19:51:41'),

(80, 1, 'f1 meme 2', 'Sebastian Buemi tries to turm car with no tires', 'Formula 1 driver Sebastian Buemi tries to turn f1 car after loosing both front tires', 'https://tse1.mm.bing.net/th?id=OIP.jqusJ7c9gxhD07FBLySITQAAAA&pid=Api&P=0&h=220', '10.00', '0.00', '2024-4-7 20:02:38'),

(81, 1, 'f1 meme 3', 'Kimi Raikkonen walking to yacht after crashing in f1 race', 'Formula 1 driver Kimi Raikonnen walking to yach after crashing out of the Monaco Grand Prix', 'https://www.bosshunting.com.au/wp-content/uploads/2021/05/DAwXT4xXYAAiQAH.jpg', '10', '0', '2024-4-7 20:09:15'),

(82, 1, 'f1 meme 4', 'Fernando Alonso basking in the sun', 'Formula 1 driver Fernando Alonso sitting in chair and basking in the sun after crashing out of race', 'https://gcdn.emol.cl/formula-1/files/2018/08/Los-10-mejores-momentos-de-Fernando-Alonso-en-la-F%C3%B3rmula-1.jpg', '10.00', '0.00', '2024-4-7 20:13:54'),

(83, 1, 'f1 meme 5', 'Lewis Hamilton walking back to garage', 'Formula 1 driver Lewis Hamilton walking back to garage after crashing out of race', 'https://www.telegraph.co.uk/content/dam/formula-1/2022/08/29/TELEMMGLPICT000307196275_trans_NvBQzQNjv4BqglhRsynS7DKriU59OtnnwnQSvaTJxsiC_Egqevvjmg4.jpeg?imwidth=680', '10.00', '0.00', '2024-4-7 20:16:35'),

(84, 1, 'f1 meme 6', 'Toto Wolf smashing headphones', 'Mercedes team principle Toto Wolf smashes headphones off table', 'https://lede-admin.defector.com/wp-content/uploads/sites/28/2021/12/Screen-Shot-2021-12-06-at-4.34.13-PM.png?resize=1080,494', '10.00', '0.00', '2024-4-7 20:22:46'),

(85, 1, 'f1 meme 7', 'Confused Sergio', 'Formula 1 driver Sergion Perez with a confused look on his face', 'https://i.ytimg.com/vi/Bj0UQBstWMc/maxresdefault.jpg', '10.00', '0.00', '2024-4-7 20:28:28'),

(86, 1, 'f1 meme 8', 'Vettel on moped', 'Formula 1 Driver Sebastian Vettel on moped after crashing in race', 'https://metro.co.uk/wp-content/uploads/2022/04/Screenshot-2022-04-08-at-17.29.45-9546.png?quality=90&strip=all&zoom=1&resize=644%2C353', '10.00', '0.00', '2024-4-7 20:33:50'),

(87, 1, 'f1 meme 9', 'Sad Fernando', 'Formula 1 driver Fernando Alonso after loosing 2012 world championship', 'https://d3cm515ijfiu6w.cloudfront.net/wp-content/uploads/2020/02/10114608/Fernando-Alonso-768x576.png', '10.00', '0.00', '2024-4-7 20:38:24'),

(88, 1, 'f1 meme 10', 'Lonely Lewis', 'Formula 1 driver Lewis Hamilton restarts race as only car on the grid', 'https://talksport.com/wp-content/uploads/sites/5/2021/08/LewisHamilton.jpg?strip=all&w=960&quality=100', '10.00', '0.00', '2024-7-4 20:42:22'),

(89, 1, 'Humerous', 'Food Meme', 'Meme about food', 'https://img.delicious.com.au/WqbvXLhs/del/2016/06/more-the-merrier-31380-2.jpg',
'699.00', '30.00', '2024-04-03 12:30:40'),

(90, 2, 'PoliticalMeme', 'ImPeachMint', 'Impeachment meme',
'https://www.liveabout.com/thmb/VBPMjhawb6BHPgwIwASH-bkeDCU=/750x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/trump-impeachment-ice-cream-587fed893df78c2ccdfcd957.jpg',
'12.50', '1.25', '2024-4-1 12:52'),

(91, 3, 'Animals', 'Duck Meme', 'Meme of a duck', 'https://static.demilked.com/wp-content/uploads/2023/07/hilarious-animal-memes-2.jpg',
'2517.00', '52.00', '2024-4-1 12:52'),

(92, 3, 'Animals2', 'Cat', 'Funny cat meme', 'https://bestlifeonline.com/wp-content/uploads/sites/3/2019/07/happy-tuesday-memes-funny.jpg?quality=82&strip=1&resize=1250%2C702',
'489.99', '38.00', '2024-4-1 12:52'),

(93, 1, 'Humerous2', 'Funny', 'Humorous meme', 'https://az505806.vo.msecnd.net/cms/545b1a5f-a2fa-4a94-8889-018f2229fb9a/eab5ca18-51ba-4cbf-8b6f-a3e4b9652757.jpg',
'415.00', '39.00', '2024-4-1 12:52'),

(94, 2, 'Political2', 'Funny Leaders', 'Political meme about leaders', 'https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/9d8fd311-9719-4eac-816b-e3b67774b752/dbq32pn-eaf4910f-55b7-446c-96be-dd1d102cf8ed.jpg/v1/fill/w_607,h_785,q_75,strp/wow_an_actual_funny_political_meme_by_onyxcarmine_dbq32pn-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9Nzg1IiwicGF0aCI6IlwvZlwvOWQ4ZmQzMTEtOTcxOS00ZWFjLTgxNmItZTNiNjc3NzRiNzUyXC9kYnEzMnBuLWVhZjQ5MTBmLTU1YjctNDQ2Yy05NmJlLWRkMWQxMDJjZjhlZC5qcGciLCJ3aWR0aCI6Ijw9NjA3In1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmltYWdlLm9wZXJhdGlvbnMiXX0.AsgzKJPLgm9mLKit6AmholpAmvZWtIGC1OIvNSfRu9s',
'799.99', '30.00', '2024-4-1 12:52'),

(95, 1, 'Humerous3', 'Stonks', 'Stonks meme', 'https://i.insider.com/6127fcaf12b9cc0019630bce?width=1200&format=jpeg',
'499.99', '25.00', '2024-4-1 12:52'),

(96, 1, 'Humerous4', 'Karen', 'Karen meme', 'https://i0.wp.com/hyperallergic-newspack.s3.amazonaws.com/uploads/2022/02/karenmeme-e1645956525493.jpeg?fit=1200%2C1469&quality=100&ssl=1',
'699.99', '30.00', '2024-4-1 12:52'),

(97, 3, 'Animals3', 'Dog meme', 'Meme of a dog', 'https://www.usatoday.com/gcdn/presto/2021/10/19/USAT/a03f3e6f-baa6-4025-9e14-ad593fb40034-Meme_Example_1_002.png?crop=971,971,x968,y0',
'799.99', '15.00', '2024-4-1 12:52'),

(98, 1, 'cringe', 'memories', 'Cartoon character lying in bed wide awake with thought bubbles filled with cringeworthy memories.', 'https://g1-addtext.ft-uc.com/MjAyNDA0MDM/addtext_com_MTgyMTAyOTQxNA.jpg', '15.00', '3.00', '2024-4-2 12:12'),

(99, 1, 'awkward', 'pizza', 'a person smiling awkwardly while holding pizza slices in each hand, with a salad untouched on the plate.', 'https://g1-addtext.ft-uc.com/MjAyNDA0MDM/addtext_com_MTg1ODM5OTUxMg.jpg', '20.00', '10.00', '2024-4-3 1:00'),

(100, 3, 'sloth', 'squirrel', 'A sleepy sloth contrasted with a dancing squirrel', 'https://g1-addtext.ft-uc.com/MjAyNDA0MDM/addtext_com_MTkxMDAzOTU0MQ.jpg', '30.00', '5.00', '2024-4-3 1:10'),

(101, 3, 'dogmeme', 'dog', 'A dog lifting tiny weights', 'https://g1-addtext.ft-uc.com/MjAyNDA0MDM/addtext_com_MTkxNjU3OTU2Ng.jpg', '50.00', '20.00', '2024-4-3 1:17'),

(102, 2, 'cnn', 'fox', 'CNN vs fox nows on reliability', 'https://images3.memedroid.com/images/UPLOADED112/5ea0a1dc26ec3.jpeg', '20.00', '10.00', '2024-4-3 1:20'),

(103, 2, 'biden', 'trump', 'Biden sniffing trump', 'https://oxfordpoliticalreview.com/wp-content/uploads/2021/08/thumbnail_Putting-america-first.jpg', '60.00', '30.00', '2024-4-3 1:20'),

(104, 3, 'Koala', 'coffee', 'Koala drinking coffee', 'https://g1-addtext.ft-uc.com/MjAyNDA0MDM/addtext_com_MTkyNDE4OTU2Nw.jpg', '80.00', '30.00', '2024-4-3 1:25'),

(105, 2, 'Donald Trump', 'Donald meme', 'Donald Trump poop meme', 'https://i.imgflip.com/8gvn1j.jpg', '39.99', '10.00', '2024-4-10 12:00'),

(106, 1, 'coding', 'meme', 'coding from last year', 'https://plaky.com/blog/wp-content/uploads/2023/08/Your-old-code.jpg', '37.99', '5.00', '2024-4-10 12:09');



INSERT INTO customers (customerID, emailAddress, password, firstName, lastName, shipAddressID, billingAddressID) VALUES
(1, 'madisonmcd6160@gmail.com', '650215acec746f0e32bdfff387439eefc1358737', 'Madison', 'McDonald', 1, 2), /*Added myself as Customer*/
(2, 'barryz@gmail.com', '3f563468d42a448cb1e56924529f6e7bbe529cc7', 'Barry', 'Zimmer', 3, 4),
(3, 'christineb@solarone.com', 'ed19f5c0833094026a2f1e9e6f08a35d26037066', 'Christine', 'Brown', 5, 6);

INSERT INTO addresses (addressID, customerID, line1, line2, city, state, zipCode, phone, disabled) VALUES
(1, 1, '37 Pleasant Pond Rd.', '', 'Weare', 'NH', '03281', '603-856-3035', 0),
(2, 1, '229 Main St. 5937', '', 'Keene', 'NH', '03435', '603-856-3035', 0),
(3, 2, '16285 Wendell St.', '', 'Omaha', 'NE', '68135', '402-896-2576', 0),
(4, 2, '16285 Wendell St.', '', 'Omaha', 'NE', '68135', '402-896-2576', 0),
(5, 3, '19270 NW Cornell Rd.', '', 'Beaverton', 'OR', '97006', '503-654-1291', 0),
(6, 3, '19270 NW Cornell Rd.', '', 'Beaverton', 'OR', '97006', '503-654-1291', 0);

INSERT INTO orders (orderID, customerID, orderDate, shipAmount, taxAmount, shipDate, shipAddressID, cardType, cardNumber, cardExpires, billingAddressID) VALUES
(1, 1, '2017-05-30 09:40:28', '5.00', '32.32', '2017-06-01 09:43:13', 1, 2, '4111111111111111', '04/2022', 2),
(2, 2, '2017-06-01 11:23:20', '5.00', '0.00', NULL, 3, 2, '4111111111111111', '08/2021', 4),
(3, 1, '2017-06-03 09:44:58', '10.00', '89.92', NULL, 1, 2, '4111111111111111', '04/2022', 2);

INSERT INTO orderItems (itemID, orderID, productID, itemPrice, discountAmount, quantity) VALUES
(1, 1, 2, '399.00', '39.90', 1),
(2, 2, 4, '699.00', '69.90', 1),
(3, 3, 3, '499.00', '49.90', 1),
(4, 3, 6, '549.99', '0.00', 1);

INSERT INTO administrators (adminID, emailAddress, password, firstName, lastName) VALUES
(1, 'madisonmcd6160@gmail.com', '6a718fbd768c2378b511f8249b54897f940e9022', 'Madison', 'McDonald'), /*Added myself as Admin*/
(2, 'joel@murach.com', '971e95957d3b74d70d79c20c94e9cd91b85f7aae', 'Joel', 'Murach'),
(3, 'mike@murach.com', '3f2975c819cefc686282456aeae3a137bf896ee8', 'Mike', 'Murach');

-- Create a user named mgs_user
GRANT SELECT, INSERT, UPDATE, DELETE
ON *
TO mgs_user@localhost
IDENTIFIED BY 'pa55word';