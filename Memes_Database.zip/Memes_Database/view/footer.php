
<footer>
    <p id="copyright">
        &copy; <?php echo date("Y"); ?> My Meme Shop, Inc.
    </p>
</footer>
</body>
</html>